package com.example.shared_pref

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
