package com.example.random_number_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
